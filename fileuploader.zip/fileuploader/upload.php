<?php
$fname="uploads/".time().$_FILES['file']['name'];
$tmpnm=$_FILES['file']['tmp_name'];
move_uploaded_file($tmpnm,$fname);
?>
// jquery xhr upload
jQuery.fn.draguploader = function(options) {
 var defaults = {
 url:'',
 allowExts : 'all',
 filesize:2,
 text:'Drag & Drop Files Here',
 hideprogress:false,
 auto:true
 };

 var o = jQuery.extend(defaults, options);
 var maxFileSize=o.filesize;
 var uploadUrl=o.url;
 var showText=o.text;
 var fileType=o.allowExts;
 var autoUpload=o.auto;
  var hideAftercomp=o.hideprogress
 var draguploaderfilecount=0;


   var globalformdaat =[];
   var globalformdaats =[];
   var abc=0;

 return this.each(function() {
   var obj = jQuery(this);
 
   obj.addClass('dragandrophandler');
   obj.text(showText);
obj.on('dragenter', function (e)
{
    e.stopPropagation();
    e.preventDefault();
    jQuery(this).css('border', '2px solid #0B85A1');
});
obj.on('dragover', function (e)
{
     e.stopPropagation();
     e.preventDefault();
});
obj.on('drop', function (e)
{
 
     jQuery(this).css('border', '2px dotted #0B85A1');
     e.preventDefault();
     var files = e.originalEvent.dataTransfer.files;
 
     //We need to send dropped files to Server
     handleFileUpload(files,obj);
});
jQuery(document).on('dragenter', function (e)
{
    e.stopPropagation();
    e.preventDefault();
});
jQuery(document).on('dragover', function (e)
{
  e.stopPropagation();
  e.preventDefault();
  obj.css('border', '2px dotted #0B85A1');
});
jQuery(document).on('drop', function (e)
{
    e.stopPropagation();
    e.preventDefault();
});



jQuery(document).on('click','.canclec', function (e)
{
	var cf=$(this).data("index");
 removefilefromQ(cf)
});



	


     function sendFileToServer(formData,status)
{
    var uploadURL =uploadUrl; //Upload URL
    var extraData ={}; //Extra Data.
    var jqXHR=jQuery.ajax({
            xhr: function() {
            var xhrobj = jQuery.ajaxSettings.xhr();
            if (xhrobj.upload) {
                    xhrobj.upload.addEventListener('progress', function(event) {
                        var percent = 0;
                        var position = event.loaded || event.position;
                        var total = event.total;
                        if (event.lengthComputable) {
                            percent = Math.ceil(position / total * 100);
                        }
                        //Set progress
                        status.setProgress(percent);
                    }, false);
                }
            return xhrobj;
        },
    url: uploadURL,
    type: "POST",
    contentType:false,
    processData: false,
        cache: false,
        data: formData,
        success: function(data){
            status.setProgress(100);
 
                  
        }
    });
    		if(autoUpload){
    status.setAbort(jqXHR);
	}
}
var rowCount=0;
function createStatusbar(obj,cindex)
{
     rowCount++;
     var row="odd";
     if(rowCount %2 ==0) row ="even";
     this.statusbar = jQuery("<div id='statsbar_"+cindex+"' class='statusbar "+row+"'></div>");
     this.filename = jQuery("<div class='filename'></div>").appendTo(this.statusbar);
     this.size = jQuery("<div class='filesize'></div>").appendTo(this.statusbar);
     this.progressBar = jQuery("<div class='progressBar'><div></div></div>").appendTo(this.statusbar);
	 if(!autoUpload){
          this.doupload=jQuery("<div data-index='"+cindex+"' class='upload'>Upload</div>").appendTo(this.statusbar);
	      this.cupload=jQuery("<div data-index='"+cindex+"'  class='canclec' >Cancel</div>").appendTo(this.statusbar);
	 }else{
	 	 this.abort = jQuery("<div class='abort'>Abort</div>").appendTo(this.statusbar);
	 }
    
     obj.after(this.statusbar);
 
    this.setFileNameSize = function(name,size)
    {
		var allowup=true;
		var msg='';
		var ext =name.split('.').pop().toLowerCase();
		if(fileType!='all'){
		if($.inArray(ext,fileType) == -1) {
		 if(!autoUpload){
		 this.doupload.hide();
		  this.cupload.hide();
		 }else{
		 	 this.progressBar.hide()
			 this.abort.hide()
		 }
		msg='<span class="error">invalid extension! </span>';
		allowup=false;
		}
		}
		 var infileSize=(Math.round(size * 100 / (1024 * 1024)) / 100);
	     if(infileSize>maxFileSize){
		 msg='<span class="error"> Upload Faild Maximum file size '+maxFileSize+' MB </span>';
		 if(!autoUpload){
		 this.doupload.hide();
		  this.cupload.hide();
		 }else{
		 	 this.progressBar.hide()
			 this.abort.hide()
		 }
			allowup=false;
		}
		if(allowup){
			
		
        var sizeStr="";
        var sizeKB = size/1024;
        if(parseInt(sizeKB) > 1024)
        {
            var sizeMB = sizeKB/1024;
           msg= sizeStr = sizeMB.toFixed(2)+" MB";
        }
        else
        {
            msg=sizeStr = sizeKB.toFixed(2)+" KB";
        }
	//	this.size.html(sizeStr);
		}else{
			
	var x= this.statusbar;
		setTimeout(function(){
			x.hide();
			
		},3000)	

		}
      this.size.html(msg);
        this.filename.html(name);
        return allowup;
    }
    this.setProgress = function(progress)
    {      
        var progressBarWidth =progress*this.progressBar.width()/ 100; 
        this.progressBar.find('div').animate({ width: progressBarWidth }, 10).html(progress + "% ");
        if(parseInt(progress) >= 100)
        {
			if(hideAftercomp){
				this.statusbar.hide();
			}
			
		 if(autoUpload){
            this.abort.hide();
			}
			else{
			this.doupload.hide();
		    this.cupload.hide();
			}
        }
    }
		if(autoUpload){
    this.setAbort = function(jqxhr)
    {
        var sb = this.statusbar;
		
        this.abort.click(function()
        {
            jqxhr.abort();
            sb.hide();
        });
    }
	}
}
function handleFileUpload(files,obj)
{
   for (var i = 0; i < files.length; i++)
   {
   
        var fd = new FormData();
        fd.append('file', files[i]);
 
        var status = new createStatusbar(obj,draguploaderfilecount); //Using this we can set progress.
		
       if(status.setFileNameSize(files[i].name,files[i].size)){
	   	
		if(autoUpload){
        sendFileToServer(fd,status);
		}
		else{
		
			globalformdaat.push(fd);
			globalformdaats.push(status);
			jQuery(document).on('click','.upload', function (e)
			{
				var cf=$(this).data("index");
				uploadfilefromQ(cf,globalformdaat,globalformdaats);
		});
		}
		
	   }
	   	draguploaderfilecount++;
   }
}

function removefilefromQ(cfile){
	jQuery("#statsbar_"+cfile).remove();
}

function uploadfilefromQ(cfile,globalt,globalts){
	var cfd=globalt[cfile];
	var cstatus=globalts[cfile];
	
	 sendFileToServer(cfd,cstatus);
}
  });
};
/** The root URL AND Params for the RESTful services
@var root_dir="name of project root diretory";
@var backend_dir="name of  backend where server side api stored diretory";
@var apiURL = "full path to rest api ";
@U can change it acording  your requrment
*/

var root_dir="restapi";
var api_dir="api";
var user_id="1";
var apiURL = "http://"+window.location.host+'/'+root_dir+'/'+api_dir;
